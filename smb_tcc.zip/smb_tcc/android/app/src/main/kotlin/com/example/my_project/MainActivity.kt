package com.mycompany.smbtcc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
