import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'l_o_g_i_n_criar_senha_widget.dart' show LOGINCriarSenhaWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';  // Para converter JSON.

class LOGINCriarSenhaModel extends FlutterFlowModel<LOGINCriarSenhaWidget> {
  ///  State fields for stateful widgets in this page.

  // Controllers e FocusNodes
  FocusNode? userFocusNode1;
  TextEditingController? userTextController1;
  String? Function(BuildContext, String?)? userTextController1Validator;

  FocusNode? userFocusNode2;
  TextEditingController? userTextController2;
  String? Function(BuildContext, String?)? userTextController2Validator;

  bool isLoading = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    userFocusNode1?.dispose();
    userTextController1?.dispose();
    userFocusNode2?.dispose();
    userTextController2?.dispose();
  }

  // Função para enviar as senhas para o backend.
  Future<void> enviarSenha(String email) async {
    String senha = userTextController1?.text ?? '';
    String confirmarSenha = userTextController2?.text ?? '';

    if (senha.isEmpty || confirmarSenha.isEmpty) {
      // Mensagem de erro caso os campos estejam vazios.
      mostrarMensagem(context, "Por favor, preencha ambos os campos.");
      return;
    }

    if (senha != confirmarSenha) {
      // Mensagem de erro se as senhas não coincidirem.
      mostrarMensagem(context, "As senhas não coincidem.");
      return;
    }

    isLoading = true;

    try {
      var url = Uri.parse('https://seu_dominio.com/api/atualizar_senha.php');

      var response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'email': email,  // Passando o email do usuário.
          'senha': senha,
          'confirmarSenha': confirmarSenha,
        }),
      );

      var jsonResponse = json.decode(response.body);

      if (response.statusCode == 200 && jsonResponse['status'] == 'success') {
        // Se tudo der certo, mostrar mensagem de sucesso.
        mostrarMensagem(context, "Senha atualizada com sucesso.");
      } else {
        // Se houver algum erro, mostrar a mensagem de erro.
        mostrarMensagem(context, jsonResponse['message']);
      }
    } catch (e) {
      mostrarMensagem(context, "Erro ao conectar ao servidor.");
    }

    isLoading = false;
  }

  void mostrarMensagem(BuildContext context, String mensagem) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensagem)),
    );
  }
}
