import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<login> {
  final TextEditingController _emailController = TextEditingController();

  Future<void> _verificarEmail() async {
    final String email = _emailController.text;

    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2/api/conexao.php'), // Altere para sua URL do PHP
        body: {'email': email},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['message'] == 'Email encontrado') {
          // Navega para a página de criar senha se o email for encontrado
          Navigator.pushReplacementNamed(context, '/l_o_g_i_n_criar_senha');
        } else if (data['message'] == 'Email não encontrado') {
          // Navega para a página de contratação se o email não for encontrado
          Navigator.pushReplacementNamed(context, '/link_contratacao');
        } else {
          // Exibe uma mensagem de erro genérica
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro: Resposta inesperada do servidor')),
          );
        }
      } else {
        // Exibe uma mensagem de erro se houver falha na conexão
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro: ${response.statusCode}')),
        );
      }
    } catch (e) {
      // Exibe uma mensagem de erro se houver exceção na requisição
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao se conectar ao servidor: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verificar Email'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Digite seu e-mail',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _verificarEmail,
              child: Text('Verificar Email'),
            ),
          ],
        ),
      ),
    );
  }
}
