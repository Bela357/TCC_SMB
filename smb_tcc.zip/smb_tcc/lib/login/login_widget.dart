import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'login_model.dart';
export 'login_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginWidget extends StatefulWidget {
  const LoginWidget({super.key});

  @override
  State<LoginWidget> createState() => _LoginWidgetState();
}

class _LoginWidgetState extends State<LoginWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  final TextEditingController _emailController = TextEditingController();
  final FocusNode _emailFocusNode = FocusNode();

  Future<void> _verificarEmail() async {
    final String email = _emailController.text;

    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2/api/conexao.php'), // Altere para sua URL do PHP
        body: {'email': email},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['message'] == 'Email encontrado') {
          // Navega para a página de criar senha se o email for encontrado
          Navigator.pushReplacementNamed(context, '/l_o_g_i_n_criar_senha');
        } else if (data['message'] == 'Email não encontrado') {
          // Navega para a página de contratação se o email não for encontrado
          Navigator.pushReplacementNamed(context, '/link_contratacao');
        } else {
          // Exibe uma mensagem de erro genérica
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Erro: Resposta inesperada do servidor')),
          );
        }
      } else {
        // Exibe uma mensagem de erro se houver falha na conexão
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro: ${response.statusCode}')),
        );
      }
    } catch (e) {
      // Exibe uma mensagem de erro se houver exceção na requisição
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao se conectar ao servidor: $e')),
      );
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _emailFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    'assets/images/Prottipos_de_Alta_Definio.png',
                    width: 410.0,
                    height: 990.0,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(-0.01, 0.51),
                child: Text(
                  'LOGIN',
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(-0.01, 0.78),
                child: Container(
                  width: 220.0,
                  child: TextFormField(
                    controller: _emailController,
                    focusNode: _emailFocusNode,
                    onFieldSubmitted: (_) async {
                      _verificarEmail();
                    },
                    autofocus: false,
                    decoration: InputDecoration(
                      isDense: true,
                      hintText: 'DIGITE SEU EMAIL',
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(-0.01, 0.86),
                child: ElevatedButton(
                  onPressed: () async {
                    _verificarEmail();
                  },
                  child: Text('OK'),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(-0.99, 1.09),
                child: Container(
                  width: 399.0,
                  height: 49.0,
                  decoration: BoxDecoration(
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
